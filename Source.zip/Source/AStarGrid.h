#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AStarNode.h"
#include "AStarGrid.generated.h"

UCLASS()
class YOURPROJECT_API AStarGrid : public AActor
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Width = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Height = 10;

    UPROPERTY(BlueprintReadWrite)
    TArray<AStarNode*> Nodes;

    UFUNCTION(BlueprintCallable)
    void GenerateGrid();
};

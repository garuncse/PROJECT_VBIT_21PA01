TArray<AStarNode*> AStarAlgorithm::FindPath(AStarNode* StartNode, AStarNode* EndNode)
{
    OpenList.Add(StartNode);

    AStarNode* EndNode = GetNodeByCoordinates(TargetX, TargetY);
    if (EndNode == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("EndNode is null!"));
        return TArray<AStarNode*>();
    }
    
    while (OpenList.Num() > 0)
    {
        AStarNode* CurrentNode = OpenList[0];
        for (AStarNode* Node : OpenList)
        {
            if (Node->FCost < CurrentNode->FCost || 
                (Node->FCost == CurrentNode->FCost && Node->HCost < CurrentNode->HCost))
            {
                CurrentNode = Node;
            }
        }

        OpenList.Remove(CurrentNode);
        ClosedList.Add(CurrentNode);

        if (CurrentNode == EndNode) break;

        // Add neighbor logic here
    }

    // Trace back the path
    TArray<AStarNode*> Path;
    AStarNode* Node = EndNode;
    while (Node != nullptr)
    {
        Path.Add(Node);
        Node = Node->Parent;
    }
    
    Algo::Reverse(Path);
    return Path;
    
}
